 <!-- Begin Page Content -->
 <div class="container-fluid">

     <!-- Page Heading -->
     <div class="d-sm-flex align-items-center justify-content-between mb-4">
         <h1 class="h3 mb-0 text-gray-800">Paket Per Kelas</h1>
 
     </div>


     <!-- Content Row -->

     <div class="row">

         <!-- Area Chart -->
         <div class="col-xl-12">

             <div class="card shadow mb-4">
                 <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                     <h6 class="m-0 font-weight-bold text-primary">Data Kelas per Paket</h6>
                 </div>

                 <div class="card-body">
                    <a class='btn btn-primary' href='#' data-toggle='modal' data-target='#tambahPaket'>Tambah</a>
                    <br><br>
                     <?php
                
                        $perintah = $isi->eksekusiSQl("SELECT *FROM paket_kelas
                                                        INNER JOIN kelas ON kelas.id_kelas=paket_kelas.id_kelas
                                                        INNER JOIN paket_member ON paket_member.id_paket=paket_kelas.id_paket");
                        $hitung   = $isi->hitungData($perintah);

                        if ($hitung==0) 
                        {
                            pesanKosong();
                        }
                        else
                        {
                           echo
                           "
                           <div class='table-responsive'>
                                <table class='table table-bordered table-hover' id='dataTable' width='100%' cellspacing='0'>
                                    <thead class='thead-dark'>
                                        <tr>
                                            <th>No.</th>
                                            <th>Nama Paket</th>
                                            <th>Nama Kelas</th>

                                          
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                            ";

                            //$tampilin = $isi->tampilData("paket_member");

                            $no=1;
                            foreach($perintah as $a)
                            {
                                $idp       = $a['id_paketkelas'];

                                $namapak   = $a['nama_paket'];
                                $kelas     = $a['nama_kelas'];
                                

                                $foto   = $a['foto_paket'];
                               
                              

                                if ($foto=='Kosong') 
                                {
                                    $gambar = "<img class='rounded-circle' src='../img/nofoto.png' width='50' height='50'><br> <br>";
                                    $box = "";
                                } 
                                else 
                                {
                                    $tujuan = "../foto/paket/$foto";
                                    $gambar = 
                                    "   <a data-fancybox='' href='$tujuan' data-caption='$namapak'>
                                            <img src='$tujuan' width='50' height='50'>
                                        </a>
                                        <br> <br>
                                    ";
                                    $box = 
                                    "
                                        <center>
                                        <img src='$tujuan' width='70%' height='200'>
                                        </center>
                                        <br>
                                    ";

                                    //$hargaRp = "Rp ".formatRupiah($harga).",-";

                                    
                                }
                                
                                
                                
                                
                                echo
                                "
                                    <tbody>
                                        <tr>
                                            <td align='center'>$no</td>
                                        
                                            <td>
                                                <center>
                                                    $gambar
                                                    $namapak
                                                </center>
                                            </td>
                                            
                                            <td>$kelas</td>
                                            
                                            
                                            <td>
                                                <center>
                                                    <a class='btn btn-warning' href='?hal=membership-edit&id=$idp'>Edit</a>
                                                    <a class='btn btn-danger' href='?hal=membership-respon&mau=hapus&id=$idp'>Hapus</a>
                                                </center>
                                            </td>
                                        </tr>
                                ";
                                $no++;
                            }
                            
                            

                            echo
                            "
                                    </tbody>
                                </table>
                            </div>
                           "; 
                        }

                    ?>
                 </div>
             </div>



         </div>


     </div>


 </div>
 <!-- /.container-fluid -->



 
 <!-- Modal -->
 <div class="modal fade" id="tambahPaket" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
     <div class="modal-dialog" role="document">
         <div class="modal-content">
                 <div class="modal-header">
                         <h5 class="modal-title">Tambah Kelas</h5>
                             <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                 <span aria-hidden="true">&times;</span>
                             </button>
                     </div>
             <div class="modal-body">
                 <div class="container-fluid">
                     <form action="?hal=paket-respon&mau=tambah" method="post">
                    
                     <div class="form-group" style="margin-right: 30px;">
                            <select name="idpaket" class="form-control" style="width: 100%;" required>
                                <option value="">Pilih Paket</option>
                                <?php

                                $perintah = $isi->eksekusiSQl("SELECT *FROM paket_member");



                                // $tampilin = $isi->tampilData("user");


                                foreach ($perintah as $a) {
                                    $idpak  = $a['id_paket'];
                                    $namapak = $a['nama_paket'];


                                    echo
                                    "
                                        <option value='$idpak'>$namapak</option>
                                    ";
                                }






                                ?>
                            </select>
                        </div>



                        <div class="form-group" style="margin-right: 30px;">
                            <select name="idkelas" class="form-control" required>
                                <option value="">Pilih Kelas</option>
                                <?php

                                $perintah = $isi->eksekusiSQl("SELECT *FROM kelas");



                                // $tampilin = $isi->tampilData("user");


                                foreach ($perintah as $a) {
                                    $idkel  = $a['id_kelas'];
                                    $namakel = $a['nama_kelas'];


                                    echo
                                    "
                                            <option value='$idkel'>$namakel</option>
                                        ";
                                }






                                ?>
                            </select>
                        </div>

                       
                    
                 </div>
             </div>
        
             <div class="modal-footer">
                <input type="submit" value="SIMPAN" class="btn btn-primary">
                </form>
             </div>
         </div>
     </div>
 </div>
 
 <script>
     $('#exampleModal').on('show.bs.modal', event => {
         var button = $(event.relatedTarget);
         var modal = $(this);
         // Use above variables to manipulate the DOM
         
     });
 </script>